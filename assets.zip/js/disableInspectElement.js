// document.addEventListener("contextmenu", function (e) {
//     e.preventDefault();
// });

// document.onkeydown = function (e) {
//     if (event.keycode == 123) {
//         return false;
//     }
//     if ((e.ctrlKey && e.shiftKey && e.keyCode == 73) || (e.ctrlKey && e.shiftKey && e.keyCode == 74)) {
//         return false;
//     }
//     if (e.ctrlKey && e.shiftKey && e.keyCode == "I".charCodeAt(0)) {
//         return false;
//     }
//     if (e.ctrlKey && e.shiftKey && e.keyCode == "C".charCodeAt(0)) {
//         return false;
//     }
//     if (e.ctrlKey && e.shiftKey && e.keyCode == "J".charCodeAt(0)) {
//         return false;
//     }
    // if (e.ctrlKey && e.keyCode == "U".charCodeAt(0)) {
    //     return false;
    // }
// };



  // <!-- Disable Inspect Element -->
  
// window.oncontextmenu = function () {
//     return false;
//   }
//   $(document).keydown(function (event) {
//     if (event.keyCode == 123) {
//       return false;
//     }
//     else if ((event.ctrlKey && event.shiftKey && event.keyCode == 73) || (event.ctrlKey && event.shiftKey && event.keyCode == 74)) {
//       return false;
//     }
//     else if (event.ctrlKey && event.keyCode == "U".charCodeAt(0)) {
//       return false;
//     }
//     else if (event.ctrlKey && event.shiftKey && event.keyCode == "I".charCodeAt(0)) {
//       return false;
//     }
//     else if (event.ctrlKey && event.shiftKey && event.keyCode == "C".charCodeAt(0)) {
//       return false;
//     }
//     else if (event.ctrlKey && event.shiftKey && event.keyCode == "J".charCodeAt(0)) {
//       return false;
//     }
//   });